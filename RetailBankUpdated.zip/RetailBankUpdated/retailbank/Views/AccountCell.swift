//
//  AccountCell.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/13/22.
//

import UIKit

class AccountCell: UITableViewCell {
    
    @IBOutlet weak var accountName: UILabel!
    @IBOutlet weak var accountBalance: UILabel!
    @IBOutlet weak var viewTransactions: UILabel!

    @IBOutlet weak var accountCellContent: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        viewTransactions.backgroundColor = K.viewTransactionsBGColor
        viewTransactions.layer.cornerRadius = K.cornerRadius
        viewTransactions.layer.masksToBounds = true
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
