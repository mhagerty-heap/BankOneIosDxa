//
//  ViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/9/22.
//

import UIKit
//import Heap
import HeapSwiftCore
import ContentsquareModule

class MainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var topNavView: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var accountsView: UIView!
    @IBOutlet weak var billPayView: UIView!
    @IBOutlet weak var billPayReminderView: UIView!
    @IBOutlet weak var centerView: UIView!
    
    @IBOutlet weak var newAccountButton: UIButton!
    @IBOutlet weak var accountsNav: UIButton!
    @IBOutlet weak var billPayNav: UIButton!
    @IBOutlet weak var addPayeeButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var settingsNav: UIButton!

    @IBOutlet var sideNavCollection: [UIButton]!
    
    @IBOutlet weak var bottomNavView: UIView!
    @IBOutlet weak var accountsTableView: UITableView!
    @IBOutlet weak var payeesTableView: UITableView!
    @IBOutlet weak var sideNavView: UIStackView!
    
    @IBOutlet weak var notification1Label: UILabel!
    @IBOutlet weak var notification2Label: UILabel!
    
    var payeeDesc: String = ""
    
    var accounts = [
        AccountSummary(accountName: "Regular Checking (XX91)", accountNumber: 000392841, accountBalance: 4096.12),
        AccountSummary(accountName: "Regular Savings (XX45) ", accountNumber: 000392842, accountBalance: 12342.68),
        AccountSummary(accountName: "Money Market Savings (XX82)", accountNumber: 00419381, accountBalance: 8374.43),
        AccountSummary(accountName: "Rewards Credit Card (xx17)", accountNumber: 312456398754, accountBalance: 2938.71),
        AccountSummary(accountName: "12 Month CD (xx26)", accountNumber: 312456398754, accountBalance: 5000.00)
    ]
    
    var payees = [
        Payee(payeeName: "Adventure Plumbing", payeeType: K.business, daysSinceLastPmt: 90),
        Payee(payeeName: "Amy Smith", payeeType: K.person, daysSinceLastPmt: 37),
        Payee(payeeName: "Belmont Insurance", payeeType: K.business, daysSinceLastPmt: 25),
        Payee(payeeName: "Candlesticks & More", payeeType: K.retail, daysSinceLastPmt: 4),
        Payee(payeeName: "City Tree Service", payeeType: K.business, daysSinceLastPmt: 100),
        Payee(payeeName: "Mike Haynes", payeeType: K.person, daysSinceLastPmt: 999),
        Payee(payeeName: "Morris Eye & Ear", payeeType: K.business, daysSinceLastPmt: 180),
        Payee(payeeName: "Northeast Dental", payeeType: K.business, daysSinceLastPmt: 44),
        Payee(payeeName: "Sullivan Landscaping", payeeType: K.business, daysSinceLastPmt: 12),
        Payee(payeeName: "The Optical House", payeeType: K.business, daysSinceLastPmt: 135),
        Payee(payeeName: "Town Gas and Electric", payeeType: K.business, daysSinceLastPmt: 25),
        Payee(payeeName: "Wakefield Water", payeeType: K.business, daysSinceLastPmt: 80)
    ]
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
    
        super.viewDidLoad()

        formatCurrency()

        // register the accounts table view and payees table view
        self.accountsTableView.register(UINib(nibName: K.accountCellNibName, bundle: nil), forCellReuseIdentifier: K.accountCellIdentifier )
        self.accountsTableView.dataSource = self
        self.payeesTableView.register(UINib(nibName: K.payeeCellNibName, bundle: nil), forCellReuseIdentifier: K.payeeCellIdentifier )
        self.accountsTableView.dataSource = self
        
        newAccountButton.layer.borderColor = K.buttonBorderColor
        newAccountButton.layer.cornerRadius = K.cornerRadius
        newAccountButton.layer.masksToBounds = true
        addPayeeButton.layer.borderColor = K.buttonBorderColor
        addPayeeButton.layer.cornerRadius = K.cornerRadius
        addPayeeButton.layer.masksToBounds = true
        
        // side nav solution: https://www.youtube.com/watch?v=rV3lGy1xdv4
        sideNavView.transform = CGAffineTransform(translationX: 8, y: 10)
        sideNavView.alpha = K.sideNavTransparency
        hideSideNavButtons()
        
        centerView.bringSubviewToFront(sideNavView)

        configAccountsView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        if (!accountsView.isHidden) {
            //Contentsquare.send(screenViewWithName: "AccountsView")
        } else if (!billPayView.isHidden) {
            //Contentsquare.send(screenViewWithName: "BillPayView")
        }
    }
      
    func formatCurrency() {
        
        let currency = defaults.object(forKey: K.defaultCurrency) as! String
        
        // update the Accounts image to show the correct currency
        switch currency {
            case K.locale_GB:
                accountsNav.setImage(UIImage(named: K.pound), for: UIControl.State.normal)
            case K.locale_EU:
                accountsNav.setImage(UIImage(named: K.euro), for: UIControl.State.normal)
            default:
                accountsNav.setImage(UIImage(named: K.dollar), for: UIControl.State.normal)
        }

        // format notification area with correct currency
        let currencySymbol = Locale(identifier: currency).currencySymbol!
        notification1Label.text = "Mary Jones has sent you " + currencySymbol + "30."
        notification2Label.text = "A withdrawal of " + currencySymbol + "2450 was made."
    }
    
    @IBAction func sideNavMenuTouch(_ sender: Any) {
        
        if sideNavView.isHidden {
            sideNavView.isHidden = !sideNavView.isHidden
            sideNavCollection.forEach { (btn) in
                UIView.animate(withDuration: 0.5) {
                    btn.isHidden = false
                    btn.alpha = K.sideNavTransparency
                }
            }
        } else {
            hideSideNavButtons()
        }
    }
    
    @IBAction func sideNavButtonTouch(_ sender: UIButton) {

        hideSideNavButtons()
        
        switch sender.titleLabel!.text {
            case "Accounts":
                configAccountsView()
            case "Bill Pay":
                configBillPayView()
            case "Transfers":
                unavailableFeature()
            case "Settings":
                performSegue(withIdentifier: K.settingsSegue, sender: self)
            default:
                break
        }
    }
    
    func hideSideNavButtons() {
        
        sideNavView.isHidden = true
        sideNavCollection.forEach { (btn) in
            btn.isHidden = true
            btn.alpha = 0
        }
    }
    
    @IBAction func logoutTouch(_ sender: Any) {
        
        // reset identify and go back to login screen
        Heap.shared.resetIdentity()
        self.dismiss(animated: true, completion: nil)
    }
    
    func configAccountsView() {
        
        // default shows accountsView table and has the accounts nav menu highlighted
        // hide billPayView
        accountsView.isHidden = false
        billPayView.isHidden = true
        accountsNav.tintColor = UIColor.tintColor
        billPayNav.tintColor = UIColor.black
        //Contentsquare.send(screenViewWithName: "AccountsView")
    }

    func configBillPayView() {
        
        // hide accountsView, show billPayView, highlight billPay nav menu
        accountsView.isHidden = true
        billPayView.isHidden = false
        billPayNav.tintColor = UIColor.tintColor
        accountsNav.tintColor = UIColor.black
        //Contentsquare.send(screenViewWithName: "BillPayView")
    }
    
    @IBAction func accountsTouch(_ sender: UIButton) {
        configAccountsView()
    }

    @IBAction func billPayTouch(_ sender: UIButton) {
        configBillPayView()
    }
    
    @IBAction func transfersTouch(_ sender: UIButton) {
        unavailableFeature()
    }
    
    @IBAction func openAccountTouch(_ sender: UIButton) {
        unavailableFeature()
    }
    func unavailableFeature() {
        
        let refreshAlert = UIAlertController(title: "", message: "This feature is not supported yet on our mobile app.  Please visit our website.", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
            if (!self.accountsView.isHidden) {
                //Contentsquare.send(screenViewWithName: "Retail Bank Accounts View")
            } else if (!self.billPayView.isHidden) {
                //Contentsquare.send(screenViewWithName: "Retail Bank BillPay View")
            }
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
        //Contentsquare.send(screenViewWithName: "Retail Bank Unavailable Feature View")
    }
      
    @IBAction func settingsTouch(_ sender: UIButton) {
        performSegue(withIdentifier: K.settingsSegue, sender: self)
    }
    
    func appendPayee(payee: String, type: String, daysSince: Int) {
        
        // append the new payee and sort the payees array of strucs by name
        payees.append(Payee(payeeName: payee, payeeType: type, daysSinceLastPmt: daysSince))
        payees.sort(by: {$0.payeeName < $1.payeeName})
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        // set the number of rows for the accounts list and the payee list
        if tableView == accountsTableView {
            return accounts.count
        }
        else if tableView == payeesTableView {
            return payees.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // build the account listing
        if tableView == accountsTableView {
            let cell = accountsTableView.dequeueReusableCell(withIdentifier: K.accountCellIdentifier, for: indexPath) as! AccountCell
    
            let numberFormatter = NumberFormatter()
            numberFormatter.locale = Locale(identifier: defaults.object(forKey: K.defaultCurrency) as! String)
            numberFormatter.numberStyle = .currency
            cell.accountBalance.text = numberFormatter.string(from: NSNumber(value: accounts[indexPath.row].accountBalance))
            cell.accountName.text = accounts[indexPath.row].accountName
            return cell
        }
        
        // build the payee listing
        else if tableView == payeesTableView {
            
            var lastPaymentDescription: String
            
            // create a payee cell
            let cell = payeesTableView.dequeueReusableCell(withIdentifier: K.payeeCellIdentifier, for: indexPath) as! PayeeCell
            
            // configure and populate the payee cell with a name, icon (e.g. business, personal, retail)
            cell.payeeType.tintColor = K.payeeIconColor
            cell.payeeType.image = UIImage(named:payees[indexPath.row].payeeType)
            cell.payeeName.text = payees[indexPath.row].payeeName

            // add days since last payment message to payee cell
            if payees[indexPath.row].daysSinceLastPmt > 60 {
                lastPaymentDescription = "No payments in last 60 days."
            } else {
                let currentDate = Date()
                var dateComponent = DateComponents()
                dateComponent.day = payees[indexPath.row].daysSinceLastPmt * -1
                let pastDate = Calendar.current.date(byAdding: dateComponent, to: currentDate)
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = defaults.object(forKey: K.defaultFullDateFormat) as? String
                lastPaymentDescription = "Your last payment was on " + dateFormatter.string(from: pastDate!) + "."
            }
            cell.lastPaymentDescription.text = lastPaymentDescription

            return cell
        }
        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        // create a spinning wheel viewcontroller
        let child = SpinnerViewController()
        
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        // slight pause to simulate some work happening
        DispatchQueue.main.asyncAfter(deadline: .now() + K.thinkTime) { [self] in
            
            // then remove the spinner view controller
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()

            // show either the list of accounts or the list of payees for bill pay
            if tableView == accountsTableView {
                performSegue(withIdentifier: K.txnSegue, sender: self)
            }
            else if tableView == payeesTableView {
                payeeDesc = payees[indexPath.row].payeeName
                performSegue(withIdentifier: K.payeeSegue, sender: self)
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == K.payeeSegue {
            let destinationVC = segue.destination as! PayeeViewController
            destinationVC.payeeDesc = payeeDesc
        }
    }
    
    @IBAction func addPayeeTouch(_ sender: Any) {
        
        performSegue(withIdentifier: K.addPayeeSegue, sender: self)
    }
}
