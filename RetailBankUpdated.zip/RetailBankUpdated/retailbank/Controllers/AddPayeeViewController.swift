//
//  AddPayeeViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 1/6/23.
//

import UIKit
import ContentsquareModule

class AddPayeeViewController: UIViewController, UITextViewDelegate {

    @IBOutlet weak var payeeName: UITextField!
    @IBOutlet weak var payeeDescription: UITextField!
    @IBOutlet weak var payeeIdentifier: UITextField!
    @IBOutlet weak var payeePhoneNbr: UITextField!
    @IBOutlet weak var payeeAddress: UITextView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        addButton.layer.borderColor = K.buttonBorderColor
        addButton.layer.cornerRadius = K.cornerRadius
        addButton.layer.masksToBounds = true
        cancelButton.layer.borderColor = K.buttonBorderColor
        cancelButton.layer.cornerRadius = K.cornerRadius
        cancelButton.layer.masksToBounds = true
        
        // need to set the addressTextView delegate so that the address
        // field is cleard when the user taps into the field
        payeeAddress.delegate = self

    }

    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        //Contentsquare.send(screenViewWithName: "Retail Bank AdddPayee View")
    }
    
    // clear the addressTextView field when the user taps into it
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        payeeAddress.text = String()
    }
    
    @IBAction func addToucn(_ sender: Any) {

        // build a spinning wheel view control
        let child = SpinnerViewController()
        
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        // pause to simulate some work happening before exiting
        DispatchQueue.main.asyncAfter(deadline: .now() + K.thinkTime) { [self] in
            
            // then remove the spinner view controller
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            
            // alert the user that a payment has been scheduled
            let refreshAlert = UIAlertController(title: "", message: "Payee has been added.", preferredStyle: UIAlertController.Style.alert)
            
            refreshAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
                self.dismiss(animated: true, completion: nil)
            }))
            
            present(refreshAlert, animated: true, completion: nil)
            //Contentsquare.send(screenViewWithName: "Retail Bank Payee Added View")
        }

    }
    
    @IBAction func cancelTouch(_ sender: Any) {
        // display an alert dialog to confirm if the user wants to cancel
        let refreshAlert = UIAlertController(title: "Confirm", message: "Are you sure you wish to cancel adding this payee?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: true, completion: nil)
        }))

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
        // do nothing
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        // add the new payee to the payees array and reload the payees table view
        if let firstVC = presentingViewController as? MainViewController {
            DispatchQueue.main.async {
                firstVC.appendPayee(payee: self.payeeName.text!, type: K.business, daysSince: 0)
                firstVC.payeesTableView.reloadData()
            }
        }
    }
}
