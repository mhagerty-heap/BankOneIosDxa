//
//  SettingsViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 1/17/23.
//

import UIKit
import ContentsquareModule

class SettingsViewController: UIViewController {

    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var currencyPopup: UIButton!
    @IBOutlet weak var fullDatePopup: UIButton!
    @IBOutlet weak var abbrevDatePopup: UIButton!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()

        okButton.layer.borderColor = K.buttonBorderColor
        okButton.layer.cornerRadius = K.cornerRadius
        okButton.layer.masksToBounds = true
        
        configCurrencyPopup()
        configFullDatePopup()
        configAbbrevDatePopup()
    }
    
    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        //Contentsquare.send(screenViewWithName: "Retail Bank Settings View")
    }

    // build the popup selector for choosing which account to pay from
    func configCurrencyPopup() {
              
        let option = {(action: UIAction) in
             switch self.currencyPopup.currentTitle! {
             case K.US_currency :
                 self.defaults.set(K.locale_US, forKey:K.defaultCurrency)
             case K.EU_currency :
                 self.defaults.set(K.locale_EU, forKey:K.defaultCurrency)
             case K.HU_currency :
                 self.defaults.set(K.locale_HU, forKey:K.defaultCurrency)
             case K.CA_currency :
                 self.defaults.set(K.locale_CA, forKey:K.defaultCurrency)
             case K.CZ_currency :
                 self.defaults.set(K.locale_CZ, forKey:K.defaultCurrency)
             case K.NO_currency :
                 self.defaults.set(K.locale_NO, forKey:K.defaultCurrency)
             case K.RO_currency :
                 self.defaults.set(K.locale_RO, forKey:K.defaultCurrency)
             case K.GB_currency :
                 self.defaults.set(K.locale_GB, forKey:K.defaultCurrency)
             case K.BG_currency :
                 self.defaults.set(K.locale_BG, forKey:K.defaultCurrency)
             case K.CH_currency :
                 self.defaults.set(K.locale_CH, forKey:K.defaultCurrency)
             case K.PL_currency :
                 self.defaults.set(K.locale_PL, forKey:K.defaultCurrency)
             default :
                 self.defaults.set(K.locale_US, forKey:K.defaultCurrency)
             }
         }
         
         currencyPopup.menu = UIMenu(title: "Select Currency", children: [
             UIAction(title : K.US_currency, state: .off, handler: option),
             UIAction(title : K.EU_currency, state: .off, handler: option),
             UIAction(title : K.HU_currency, state: .off, handler: option),
             UIAction(title : K.CA_currency, state: .off, handler: option),
             UIAction(title : K.CZ_currency, state: .off, handler: option),
             UIAction(title : K.NO_currency, state: .off, handler: option),
             UIAction(title : K.RO_currency, state: .off, handler: option),
             UIAction(title : K.BG_currency, state: .off, handler: option),
             UIAction(title : K.GB_currency, state: .off, handler: option),
             UIAction(title : K.CH_currency, state: .off, handler: option),
             UIAction(title : K.PL_currency, state: .off, handler: option)])

         if defaults.object(forKey: K.defaultCurrency) != nil {

             let currency = defaults.object(forKey: K.defaultCurrency)
             
             currencyPopup.menu?.children.forEach { action in
                 guard let action = action as? UIAction else {
                     return
                 }

                 switch (action.title, currency as! String) {
                 case (K.US_currency, K.locale_US) :
                     action.state = .on
                 case (K.EU_currency, K.locale_EU) :
                     action.state = .on
                 case (K.HU_currency, K.locale_HU) :
                     action.state = .on
                 case (K.CA_currency, K.locale_CA) :
                     action.state = .on
                 case (K.CZ_currency, K.locale_CZ) :
                     action.state = .on
                 case (K.NO_currency, K.locale_NO) :
                     action.state = .on
                 case (K.RO_currency, K.locale_RO) :
                     action.state = .on
                 case (K.BG_currency, K.locale_BG) :
                     action.state = .on
                 case (K.GB_currency, K.locale_GB) :
                     action.state = .on
                 case (K.CH_currency, K.locale_CH) :
                     action.state = .on
                 case (K.PL_currency, K.locale_PL) :
                     action.state = .on
                 default :
                     action.state = .off
                 }
             }
         }
         
         currencyPopup.showsMenuAsPrimaryAction = true
         currencyPopup.changesSelectionAsPrimaryAction = true
         currencyPopup.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
    }
    
    func configFullDatePopup() {
              
        let option = {(action: UIAction) in
            self.defaults.set(self.fullDatePopup.currentTitle!, forKey:K.defaultFullDateFormat)
        }
        
        fullDatePopup.menu = UIMenu(title: "Select Full Date Format", children: [
            UIAction(title : "MM/dd/YY", handler: option),
            UIAction(title : "MM/dd/YYYY", handler: option),
            UIAction(title : "dd/MM/YY", handler: option),
            UIAction(title : "dd/MM/YYYY", handler: option),
            UIAction(title : "dd.MM.YY", handler: option),
            UIAction(title : "dd.MM.YYYY", handler: option),
            UIAction(title : "MM-dd-YY", handler: option),
            UIAction(title : "MM-dd-YYYY", handler: option),
            UIAction(title : "YYYY-MM-dd", handler: option)        ])
        
        if defaults.object(forKey: K.defaultFullDateFormat) != nil {
            
            let fullDateFormat = defaults.object(forKey: K.defaultFullDateFormat)
            
            fullDatePopup.menu?.children.forEach { action in
                guard let action = action as? UIAction else {
                    return
                }
              
                if action.title == fullDateFormat as! String {
                    action.state = .on
                } else {
                    action.state = .off
                }
            }
        }
        
        fullDatePopup.showsMenuAsPrimaryAction = true
        fullDatePopup.changesSelectionAsPrimaryAction = true
        fullDatePopup.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
    }
    
    func configAbbrevDatePopup() {
        
        let option = {(action: UIAction) in
            self.defaults.set(self.abbrevDatePopup.currentTitle!, forKey:K.defaultAbbrevDateFormat)
        }
        
        abbrevDatePopup.menu = UIMenu(title: "Select Abbreviated Date Format", children: [
            UIAction(title : "MMM d", handler: option),
            UIAction(title : "d MMM", handler: option),
            UIAction(title : "d-MMM", handler: option)])
        
        if defaults.object(forKey: K.defaultAbbrevDateFormat) != nil {
            
            let abbrevDateFormat = defaults.object(forKey: K.defaultAbbrevDateFormat)
            
            abbrevDatePopup.menu?.children.forEach { action in
                guard let action = action as? UIAction else {
                    return
                }
              
                if action.title == abbrevDateFormat as! String {
                    action.state = .on
                } else {
                    action.state = .off
                }
            }
        }
        
        abbrevDatePopup.showsMenuAsPrimaryAction = true
        abbrevDatePopup.changesSelectionAsPrimaryAction = true
        abbrevDatePopup.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
        }
    
    @IBAction func okTouch(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        if let firstVC = presentingViewController as? MainViewController {
            DispatchQueue.main.async {
                firstVC.accountsTableView.reloadData()
                firstVC.payeesTableView.reloadData()
                firstVC.formatCurrency()
            }
        }
    }
    
}
