//
//  Constants.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/13/22.
//

import UIKit

struct K {
    static let appName = "Retail Banking"
    
    static let defaultCurrency = "currency"
    static let defaultFullDateFormat = "fullDateFormat"
    static let defaultAbbrevDateFormat = "abbrevDateFormat"
    
    static let locale_US = "en_US"
    static let locale_EU = "en_EU"
    static let locale_HU = "hu_HU"
    static let locale_CA = "en_CA"
    static let locale_CZ = "cs_CZ"
    static let locale_NO = "nn_NO"
    static let locale_RO = "ro_RO"
    static let locale_BG = "bg_BG"
    static let locale_GB = "en_GB"
    static let locale_CH = "de_CH"
    static let locale_PL = "pl_PL"

    static let US_currency = "Dollars"
    static let EU_currency = "Euros"
    static let HU_currency = "Forint"
    static let CA_currency = "Loonies"
    static let CZ_currency = "Koruna"
    static let NO_currency = "Krone/Krona"
    static let RO_currency = "Leu"
    static let BG_currency = "Lev"
    static let GB_currency = "Quid"
    static let CH_currency = "Swiss Franc"
    static let PL_currency = "Zloty"

    static let accountCellIdentifier = "AccountCell" 
    static let accountCellNibName = "AccountCell"
    static let transactionCellIdentifier = "TransactionCell"
    static let transactionCellNibName = "TransactionCell"
    static let payeeCellIdentifier = "PayeeCell"
    static let payeeCellNibName = "PayeeCell"
    
    static let person = "person.svg"
    static let business = "business.svg"
    static let retail = "shopping-bag.svg"
    static let pound = "pound.svg"
    static let euro = "euro.svg"
    static let dollar = "dollar.svg"
    
    static let txnSegue = "goToTransactions"
    static let mainSegue = "goToMain"
    static let logoutSegue = "goToLogin"
    static let payeeSegue = "goToPayee"
    static let addPayeeSegue = "goToAddPayee"
    static let settingsSegue = "goToSettings"

    static let viewTransactionsBGColor = UIColor.systemGray
    static let cornerRadius = 15.0
    static let inputTextBorderColor = UIColor.systemGray5.cgColor
    static let inputTextBorderWidth = 0.75
    static let inputTextColor = UIColor.tintColor.cgColor
    static let buttonBorderColor = UIColor.tintColor.cgColor
    static let navMenuColor = UIColor.black
    static let payeeIconColor = UIColor.black
    
    static let thinkTime = 1.1
    static let sideNavTransparency = 0.95
}
