import Foundation
import HeapSwiftCore
import ContentsquareModule
@_exported import HeapContentsquareIntegrationImplementation

public extension HeapContentsquareIntegrationImplementation.HeapContentsquareIntegration {
    
    static func bind(sendHeapPageviewsToContentsquare: Bool, sendContentsquareScreenviewsToHeap: Bool) {
        bind(
            sendHeapPageviewsToContentsquare: sendHeapPageviewsToContentsquare,
            sendContentsquareScreenviewsToHeap: sendContentsquareScreenviewsToHeap,
            heap: Heap.shared,
            contentSquare: Contentsquare.self,
            getReplayProperties: { timestamp in try Contentsquare.getReplayProperties(timestamp) })
    }
}

extension Heap {
    @objc(onContentsquareScreenViewWithParameters:)
    private func onContentsquareScreenView(_ parameters: Any) {
        HeapContentsquareIntegration.shared?.onContentsquareScreenView(parameters as? [String: Any])
    }
    
    @objc
    private func extendOrCreateSession() -> NSDictionary? {
        HeapContentsquareIntegration.shared?.advanceOrExtendSession()
    }
}
