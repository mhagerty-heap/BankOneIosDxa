// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "HeapContentsquareIntegrationSDK",
    platforms: [
        .iOS(.v12),
    ],
    products: [
        .library(
            name: "HeapContentsquareIntegrationSDK",
            targets: ["HeapContentsquareIntegrationSDK"])
    ],
    dependencies: [
        .package(url: "https://github.com/heap/heap-swift-core-sdk.git", from: "0.6.1"),
        .package(url: "https://github.com/ContentSquare/CS_iOS_SDK.git", from: "4.33.0"),
    ],
    targets: [
        .target(
            name: "HeapContentsquareIntegrationSDK",
            dependencies: [
                .product(name: "HeapSwiftCore", package: "heap-swift-core-sdk"),
                .product(name: "ContentsquareModule", package: "CS_iOS_SDK"),
                "HeapContentsquareIntegrationImplementation",
            ]),
        .binaryTarget(
            name: "HeapContentsquareIntegrationImplementation",
            url: "https://cdn.heapanalytics.com/ios/heap-ios-cs-integration-0.1.0-alpha.1.zip",
            checksum: "8f7a3c6f16d7f59c414bfcf3100a5c7b214562fff56ca8a39ce7d982f4f50513"
        ),
    ]
)
