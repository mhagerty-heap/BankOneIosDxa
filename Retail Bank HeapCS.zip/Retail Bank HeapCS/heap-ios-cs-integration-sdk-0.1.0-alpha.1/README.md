# HeapContentsquareIntegrationSDK

HeapContentsquareIntegrationSDK is an iOS SDK that enables communication between the Heap and
Contentsquare SDKs.

## Installation and Usage

To be added.
