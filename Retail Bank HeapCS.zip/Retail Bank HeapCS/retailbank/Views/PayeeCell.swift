//
//  PayeeCell.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/27/22.
//

import UIKit

class PayeeCell: UITableViewCell {

    @IBOutlet weak var payeeName: UILabel!
    @IBOutlet weak var lastPaymentDescription: UILabel!
    @IBOutlet weak var payeeType: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
