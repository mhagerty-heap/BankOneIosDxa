//
//  LoginViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/26/22.
//

import UIKit
import HeapSwiftCore
import HeapIOSAutocapture
import ContentsquareModule





class LoginViewController: UIViewController {

    @IBOutlet weak var userId: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loginButton.layer.cornerRadius = K.cornerRadius
        loginButton.layer.masksToBounds = true
        userId.layer.borderWidth = 1
        password.layer.borderWidth = 1
        userId.layer.borderColor = UIColor.systemGray2.cgColor
        password.layer.borderColor = UIColor.systemGray2.cgColor
    }
    
    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        //Contentsquare.send(screenViewWithName: "Retail Bank Login View")
        Contentsquare.csInApp = true
        Contentsquare.setDefaultMasking(false)
    }
    
    @IBAction func loginTouch(_ sender: UIButton) {
        
        // build the spinning wheel view controller
        let child = SpinnerViewController()
        
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        // pause to simulate some work happening
        DispatchQueue.main.asyncAfter(deadline: .now() + K.thinkTime) { [self] in
            
            // then remove the spinner view controller
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            
            // Identify the user
            if userId.text!.isEmpty == false {
                Heap.shared.identify(userId.text!)
                let heapIdentity = Heap.shared.identity
//              print("Current identity = " + heapIdentity!)
            }

            // move on to the MainViewControler
            self.performSegue(withIdentifier: K.mainSegue, sender: self)
        }
    }
}
