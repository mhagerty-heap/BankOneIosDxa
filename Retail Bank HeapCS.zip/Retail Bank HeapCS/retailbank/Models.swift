//
//  Models.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/30/22.
//

import Foundation

struct AccountSummary {
    let accountName: String
    let accountNumber: Int
    let accountBalance: Float
}

struct Transaction {
    let txnDateOffset: Int
    let txnDescription: String
    let txnAmount: Float
}

struct Payee {
    let payeeName: String
    let payeeType: String
    let daysSinceLastPmt: Int
}
