//
//  PayeeViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/28/22.
//

import UIKit
//import Heap
import HeapSwiftCore
import ContentsquareModule

class PayeeViewController: UIViewController {
    
    var payeeDesc: String = ""
    var amt: Float = 0.00
      
    @IBOutlet weak var payeeDescription: UILabel!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var memo: UITextField!
    @IBOutlet weak var payFromPopup: UIButton!
    @IBOutlet weak var frequencyPopup: UIButton!
    @IBOutlet weak var deliverBy: UIDatePicker!
    @IBOutlet weak var earliestDeliveryDate: UILabel!
    @IBOutlet weak var availableBalance: UILabel!
    @IBOutlet weak var payButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var deliverByLabel: UILabel!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        configPayFromPopup()
        configFrequencyPopup()
        configKeyboard()
        configDeliverBy()
        configColors()
        configAvailableBalance(acct: "Checking")
                
        amount.text = "0.00"
        payeeDescription.text = payeeDesc
     }
    
    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        //Contentsquare.send(screenViewWithName: "Retail Bank Payee View")
    }
    
    // configure the available balance that is displayed below the Pay From account
    func configAvailableBalance(acct: String) {

        var acctBalance: Float
        
        if acct == "Checking" {
            acctBalance = 4096.12
        } else {
            acctBalance = 8374.43
        }

        let numberFormatter = NumberFormatter()
        numberFormatter.locale = Locale(identifier: defaults.object(forKey: "currency") as! String)
        numberFormatter.numberStyle = .currency
        
        availableBalance.text = "Available balance " + numberFormatter.string(from: NSNumber(value: acctBalance))!
    }

    // build the popup selector for choosing which account to pay from
    func configPayFromPopup() {
        
        let option = {(action: UIAction) in
            self.configAvailableBalance(acct: action.title)
        }
        
        payFromPopup.menu = UIMenu(children: [
            UIAction(title : "Checking", handler: option),
            UIAction(title : "Money Market", handler: option)])
        
        payFromPopup.showsMenuAsPrimaryAction = true
        payFromPopup.changesSelectionAsPrimaryAction = true
        payFromPopup.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
    }

    // build the popup selector for frequency of making payments
    func configFrequencyPopup() {
        
        let option = {(action: UIAction) in
        // do nothing
        }
        
        frequencyPopup.menu = UIMenu(children: [
            UIAction(title : "One Time", handler: option),
            UIAction(title : "Weekly", handler: option),
            UIAction(title : "Every 2 Weeks", handler: option),
            UIAction(title : "Every 4 Weeks", handler: option),
            UIAction(title : "Twice a Month", handler: option),
            UIAction(title : "Monthly", handler: option)]
        )
        
        frequencyPopup.showsMenuAsPrimaryAction = true
        frequencyPopup.changesSelectionAsPrimaryAction = true
        frequencyPopup.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.right
    }
    
    func configKeyboard() {
        
        // Keyboards that are displayed when users enter the memo and the amount.
        // Those keyboards do not include a "Done" button by default.
        // The next few lines add a toolbar to the top of the
        //     keyboard that includes a "Done" button.
        // Solution found here: https://www.youtube.com/watch?v=RuzHai2RVZU
                
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
                
        // flexible space added to the toolbar to align the done button on the right side
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
                
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.done, target: self, action: #selector(self.doneTouch))
        
        toolbar.setItems([flexibleSpace,doneButton], animated: true)
                
        memo.inputAccessoryView = toolbar
        amount.inputAccessoryView = toolbar

        // Set the keyboard for the amount field to use the number pad
        amount.keyboardType = .numberPad
    }

    // set minimum Deliver By date to 5 days in the future
    func configDeliverBy () {

        var dateComponent = DateComponents()
        dateComponent.day = 5
        let futureDate = Calendar.current.date(byAdding: dateComponent, to: Date())
        
        // setting the earliest possible delivery by date
        deliverBy.minimumDate = futureDate
        
        // configure label describing earliest deliver by date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = defaults.object(forKey: K.defaultAbbrevDateFormat) as? String
        deliverByLabel.text = dateFormatter.string(from: futureDate!)
        earliestDeliveryDate.text = "Earliest delivery by " + deliverByLabel.text!
        
        // Add an event to call onDidChangeDate function when value is changed.
        // This is required since the deliverBy datepicker is hidden by a label.
        deliverBy.addTarget(self, action: #selector(PayeeViewController.datePickerValueChanged(_:)), for: .valueChanged)
    }
    
    // configure the pay and cancel buttons
    func configColors() {
        
        payButton.layer.borderColor = K.buttonBorderColor
        payButton.layer.cornerRadius = K.cornerRadius
        payButton.layer.masksToBounds = true
        cancelButton.layer.borderColor = K.buttonBorderColor
        cancelButton.layer.cornerRadius = K.cornerRadius
        cancelButton.layer.masksToBounds = true
    }

    // configure the label that displays the selected deliver by date
    @objc func datePickerValueChanged(_ sender: UIDatePicker){
        
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = defaults.object(forKey: K.defaultAbbrevDateFormat) as? String
        let selectedDate: String = dateFormatter.string(from: sender.date)
        deliverByLabel.text = selectedDate
    }
    
    // Format the amount field with the proper currency code when the user
    //     presses "Done" on the numberic keypad
    @objc func doneTouch() {
        
        view.endEditing(true)

        // only format the number if it hasn't been formatted already
        
        let currency = defaults.object(forKey: K.defaultCurrency) as! String
        
        if amount.text != "" && (
            (currency.contains("_EU") && amount.text!.contains("€") == false) ||
            (currency.contains("_GB") && amount.text!.contains("£") == false) ||
            (currency.contains("_US") && amount.text!.contains("$") == false) ||
            (currency.contains("_CA") && amount.text!.contains("$") == false)) {
            let numberFormatter = NumberFormatter()
            numberFormatter.locale = Locale(identifier: defaults.object(forKey: "currency") as! String)
            let number = numberFormatter.number(from: amount.text!)
            let numberFloatValue = number?.floatValue
            amt = number!.floatValue
            numberFormatter.numberStyle = .currency
            amount.text = numberFormatter.string(from: NSNumber(value: numberFloatValue!))
        }
    }
    
    // Schedule the payment
    @IBAction func payTouch(_ sender: UIButton) {
       
        // manual Heap track call to capture the payment amount and frequency
        Heap.shared.track("Bill Pay", properties: ["Amount" : amt, "Frequency" : frequencyPopup.currentTitle!])

        // build a spinning wheel view control
        let child = SpinnerViewController()
        
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        // pause to simulate some work happening before exiting
        DispatchQueue.main.asyncAfter(deadline: .now() + K.thinkTime) { [self] in
            
            // then remove the spinner view controller
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()

            // alert the user that a payment has been scheduled
            let refreshAlert = UIAlertController(title: "", message: "Your payment has been scheduled.", preferredStyle: UIAlertController.Style.alert)

            refreshAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
                self.dismiss(animated: true, completion: nil)
            }))
            
            present(refreshAlert, animated: true, completion: nil)
            //Contentsquare.send(screenViewWithName: "Retail Bank Payment Scheduled View")
        }
    }
            
    @IBAction func cancelTouch(_ sender: UIButton) {
        
        // display an alert dialog to confirm if the user wants to cancel
        let refreshAlert = UIAlertController(title: "Confirm", message: "Are you sure you wish to cancel this payment?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
            self.dismiss(animated: true, completion: nil)
        }))

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
        // do nothing
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
}
