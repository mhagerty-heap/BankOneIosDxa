//
//  TransactionsViewController.swift
//  retailbank
//
//  Created by Glenn Schurter on 11/21/22.
//

import UIKit
import ContentsquareModule

class TransactionsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var transactionsTableView: UITableView!
    @IBOutlet weak var exitTransactionViewButton: UIButton!
    @IBOutlet weak var transactionsHeader: UILabel!
    
    var checkingTransactions = [
        Transaction(txnDateOffset: 1, txnDescription: "Debit - 4 Guys", txnAmount: -26.12),
        Transaction(txnDateOffset: 1, txnDescription: "The Optical House", txnAmount: -221.00),
        Transaction(txnDateOffset: 2, txnDescription: "Check #5612", txnAmount: -73.54),
        Transaction(txnDateOffset: 3, txnDescription: "ATM Withdrawal", txnAmount: -60.00),
        Transaction(txnDateOffset: 5, txnDescription: "ACME Gifts", txnAmount: -105.81),
        Transaction(txnDateOffset: 5, txnDescription: "Check #5611", txnAmount: -57.02),
        Transaction(txnDateOffset: 8, txnDescription: "House of Pizza", txnAmount: -14.64),
        Transaction(txnDateOffset: 11, txnDescription: "FriendPay", txnAmount: -10.00),
        Transaction(txnDateOffset: 11, txnDescription: "Payroll Deposit", txnAmount: 1745.39),
        Transaction(txnDateOffset: 12, txnDescription: "Check #5609", txnAmount: -16.39),
        Transaction(txnDateOffset: 14, txnDescription: "Fuel Depot", txnAmount: -44.67),
        Transaction(txnDateOffset: 15, txnDescription: "Check #5610", txnAmount: -62.49),
        Transaction(txnDateOffset: 17, txnDescription: "City Electric", txnAmount: -78.26),
        Transaction(txnDateOffset: 18, txnDescription: "Mobile Deposit", txnAmount: 85.00),
        Transaction(txnDateOffset: 18, txnDescription: "ATM Withdrawal", txnAmount: -60.00),
        Transaction(txnDateOffset: 18, txnDescription: "Municipal Water", txnAmount: -143.89),
        Transaction(txnDateOffset: 21, txnDescription: "Check #5608", txnAmount: -55.47),
        Transaction(txnDateOffset: 23, txnDescription: "Home Center", txnAmount: -33.48),
        Transaction(txnDateOffset: 24, txnDescription: "Service Fee", txnAmount: -5.99),
        Transaction(txnDateOffset: 24, txnDescription: "Check #5607", txnAmount: -12.62),
        Transaction(txnDateOffset: 25, txnDescription: "Check #5606", txnAmount: -307.00),
        Transaction(txnDateOffset: 27, txnDescription: "ATM Withdrawal", txnAmount: -100.00),
        Transaction(txnDateOffset: 27, txnDescription: "Mobile Deposit", txnAmount: 215.00),
        Transaction(txnDateOffset: 27, txnDescription: "FriendPay", txnAmount: -40.00),
        Transaction(txnDateOffset: 28, txnDescription: "Transfer to Savings", txnAmount: -1100.00),
        Transaction(txnDateOffset: 29, txnDescription: "Check #5605", txnAmount: -55.47),
        Transaction(txnDateOffset: 29, txnDescription: "Auto Withdrawal", txnAmount: -200.00),
        Transaction(txnDateOffset: 30, txnDescription: "ATM Withdrawal", txnAmount: -60.00),
        Transaction(txnDateOffset: 30, txnDescription: "Check #5604", txnAmount: -12.62)
    ]
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.transactionsTableView.register(UINib(nibName: K.transactionCellNibName, bundle: nil), forCellReuseIdentifier: K.transactionCellIdentifier )
        self.transactionsTableView.dataSource = self
        exitTransactionViewButton.layer.cornerRadius = K.cornerRadius
        exitTransactionViewButton.layer.masksToBounds = true
        transactionsHeader.layer.cornerRadius = 5
        transactionsHeader.layer.masksToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {

        super.viewWillAppear(animated)
        //Contentsquare.send(screenViewWithName: "Retail Bank Transactions View")
    }

    @IBAction func exitTransactionsTouch(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return checkingTransactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = transactionsTableView.dequeueReusableCell(withIdentifier: K.transactionCellIdentifier, for: indexPath) as! TransactionCell

        // add transaction description to the cell
        cell.transactionDescription.text = checkingTransactions[indexPath.row].txnDescription

        // add transaction amount to the cell
        let numberFormatter = NumberFormatter()
        numberFormatter.locale = Locale(identifier: defaults.object(forKey: K.defaultCurrency) as! String)
        numberFormatter.numberStyle = .currency
        cell.transactionAmount.text = numberFormatter.string(from: NSNumber(value: checkingTransactions[indexPath.row].txnAmount))
        
        // change font color to green for deposits
        if checkingTransactions[indexPath.row].txnAmount > 0 {
            cell.transactionAmount.textColor = UIColor.systemGreen
        }
        
        // determine transaction date by subtracting the number of days offset
        //  from the current date
        let currentDate = Date()
        var dateComponent = DateComponents()
        dateComponent.day = checkingTransactions[indexPath.row].txnDateOffset * -1
        let pastDate = Calendar.current.date(byAdding: dateComponent, to: currentDate)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = defaults.object(forKey: K.defaultFullDateFormat) as? String
        cell.transactionDate.text = dateFormatter.string(from: pastDate!)

        return cell
    }

}
